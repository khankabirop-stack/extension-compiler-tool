package com.example.unityads;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import com.unity3d.ads.IUnityAdsListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAds.UnityAdsError;
import com.unity3d.ads.UnityAds.UnityAds.AdState;

@DesignerComponent(
        version = 2,
        description = "Unity Ads extension for Kodular (supports interstitial & rewarded). Default test IDs included, can be re-initialized with real GameID.",
        category = ComponentCategory.ADVERTISING,
        nonVisible = true,
        iconName = "aiwebres/icon.png")
@UsesLibraries(libraries = "unity-ads.aar")
@UsesPermissions(permissionNames = "android.permission.INTERNET, android.permission.ACCESS_NETWORK_STATE")
public class UnityAdsTest extends AndroidNonvisibleComponent implements Component {

    private final Context context;
    private final Activity activity;
    private String gameId = "14851"; // default test Game ID (as requested)
    private boolean isTestMode = true;

    private final String DEFAULT_PLACEMENT_INTERSTITIAL = "video";
    private final String DEFAULT_PLACEMENT_REWARDED = "rewardedVideo";

    public UnityAdsTest(ComponentContainer container) {
        super(container.$form());
        this.context = container.$context();
        this.activity = (Activity) context;
        initUnityListener();
    }

    private void initUnityListener() {
        // Unity listener must be set after initialize is called - we keep a listener instance to attach later.
    }

    // Initialize Unity Ads
    @SimpleFunction(description = "Initialize Unity Ads with Game ID. Use testMode=true for test ads.")
    public void Initialize(String gameId, boolean testMode) {
        if (gameId == null || gameId.trim().isEmpty()) {
            gameId = this.gameId; // fallback to saved value
        } else {
            this.gameId = gameId;
        }
        this.isTestMode = testMode;
        try {
            // attach listener and initialize
            UnityAds.initialize(activity, this.gameId, new IUnityAdsListener() {
                @Override
                public void onUnityAdsReady(String placementId) {
                    // Called when placement becomes ready
                    OnAdLoaded(placementId);
                }

                @Override
                public void onUnityAdsStart(String placementId) {
                    // ad started
                }

                @Override
                public void onUnityAdsFinish(String placementId, com.unity3d.ads.IUnityAdsListener.FinishState finishState) {
                    // Reward logic: finished successfully
                    // Unity Ads v3+ uses UnityAds.FinishState in some APIs; adapt if compile errors occur.
                    // For safety, always emit OnRewardEarned when placement is rewarded and finishState indicates completion.
                    // We'll simply emit OnRewardEarned for rewarded placement to let user decide.
                    if (placementId != null && placementId.equals(DEFAULT_PLACEMENT_REWARDED)) {
                        OnRewardEarned(placementId);
                    }
                }

                @Override
                public void onUnityAdsError(UnityAdsError error, String message) {
                    OnAdFailed(error + ": " + message);
                }
            }, this.isTestMode);
        } catch (Exception e) {
            OnAdFailed("Initialize exception: " + e.toString());
        }
    }

    // Convenience: Initialize with default test ID
    @SimpleFunction(description = "Initialize with default test Game ID (14851) and testMode=true")
    public void InitializeWithTestIds() {
        Initialize("14851", true);
    }

    // Show Interstitial
    @SimpleFunction(description = "Show Interstitial by placement id. Use 'video' as default test placement.")
    public void ShowInterstitial(String placementId) {
        if (placementId == null || placementId.trim().isEmpty()) {
            placementId = DEFAULT_PLACEMENT_INTERSTITIAL;
        }
        try {
            if (UnityAds.isReady(placementId)) {
                UnityAds.show(activity, placementId);
            } else {
                OnAdFailed("Interstitial not ready: " + placementId);
            }
        } catch (Exception e) {
            OnAdFailed("ShowInterstitial exception: " + e.toString());
        }
    }

    // Show Rewarded
    @SimpleFunction(description = "Show Rewarded by placement id. Use 'rewardedVideo' as default test placement.")
    public void ShowRewarded(String placementId) {
        if (placementId == null || placementId.trim().isEmpty()) {
            placementId = DEFAULT_PLACEMENT_REWARDED;
        }
        try {
            if (UnityAds.isReady(placementId)) {
                UnityAds.show(activity, placementId);
            } else {
                OnAdFailed("Rewarded not ready: " + placementId);
            }
        } catch (Exception e) {
            OnAdFailed("ShowRewarded exception: " + e.toString());
        }
    }

    // Allow developer to set GameID at runtime (useful to switch to real id)
    @SimpleFunction(description = "Set Game ID (use your real Game ID to switch from test to production). Does not auto-initialize; call Initialize after setting.")
    public void SetGameId(String gameId) {
        if (gameId != null && !gameId.trim().isEmpty()) {
            this.gameId = gameId;
        }
    }

    // Events
    @SimpleEvent(description = "Called when an ad placement becomes ready")
    public void OnAdLoaded(String placementId) {
        EventDispatcher.dispatchEvent(this, "OnAdLoaded", placementId);
    }

    @SimpleEvent(description = "Called when ad failed or error occurs")
    public void OnAdFailed(String message) {
        EventDispatcher.dispatchEvent(this, "OnAdFailed", message);
    }

    @SimpleEvent(description = "Called when user should be rewarded after watching a rewarded ad")
    public void OnRewardEarned(String placementId) {
        EventDispatcher.dispatchEvent(this, "OnRewardEarned", placementId);
    }
}