UnityAdsTest Kodular Extension - Ready-to-Build Package
------------------------------------------------------

What you have here:
- Java source: src/com/example/unityads/UnityAdsTest.java
- libs/: folder where you must place the Unity Ads SDK AAR (unity-ads.aar)
- build_termux.sh: Termux script that installs a minimal toolchain and compiles an .aix using aitool (instructions)
- README below explains steps.

IMPORTANT:
- This package does NOT include the Unity Ads SDK (unity-ads.aar) due to licensing and distribution. You must download the appropriate AAR and place it into the 'libs' folder.
- Unity Ads SDK versions change frequently. The Java API used here targets Unity Ads v3/v4 style APIs; if you get compile errors, try a matching unity-ads.aar version or update the Java calls as per the SDK you download.

Official test identifiers used:
- Android Game ID (TEST): 14851
- Interstitial placement (TEST): "video"
- Rewarded placement (TEST): "rewardedVideo"

How to prepare the package (on your phone using Termux)
------------------------------------------------------
1) Install Termux (from F-Droid is recommended).
2) Open Termux and install basic tools:
   pkg update && pkg install git openjdk-17 unzip wget -y

3) Place unity-ads AAR into libs/ :
   - Download the unity-ads .aar manually (from Unity's maven or SDK release) and copy it into the 'libs' folder inside this package.
   - Rename or ensure the file is named: unity-ads.aar

4) Use KodularRush or ai2 extension compiler:
   - There are online compilers (Rush) and local shell scripts. Many users use the 'aisdk' or 'extension-builder' tools.
   - Example using 'rush' (online): you can upload the project zip to Rush's compiler. If you prefer local:
     - You'll need the App Inventor extension compiler (aicommon tools) which is non-trivial to set up on Android.

Provided Termux helper (build_termux.sh)
----------------------------------------
The included build_termux.sh tries to guide you automatically. It's not guaranteed to work on every phone. Read it and run it manually:

    cd /path/to/UnityAdsTest_Extension_Package
    bash build_termux.sh

What to do after build
----------------------
- If successful you will get UnityAdsTest.aix. Import it into Kodular (Extensions -> Import extension), drag component to screen.
- In blocks: call Initialize("14851", true) to use test ads. Later call SetGameId("YOUR_REAL_GAME_ID") and Initialize(YOUR_REAL_GAME_ID, false) to switch to production.

If you want, I can:
- Provide a step-by-step Termux command list tuned for your phone.
- Help you adapt the Java source if any compile errors come up (copy-paste the error here).

Good luck and tell me if you want me to produce the exact Termux commands for your phone now.