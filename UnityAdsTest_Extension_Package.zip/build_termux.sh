#!/data/data/com.termux/files/usr/bin/bash
# Minimal helper script to prepare a project zip you can upload to an online extension builder (rush)
# It packages src/ + libs/ into a zip ready for Rush or other online extension compilers.

set -e
ROOT="$(pwd)"
PKGNAME="UnityAdsTest"
OUTZIP="${ROOT}/${PKGNAME}.zip"

rm -f "$OUTZIP"
zip -r "$OUTZIP" src libs README.txt build_termux.sh

echo "Created ${OUTZIP}."
echo "Upload ${OUTZIP} to Rush or another AIDE/extension compiler to build the .aix file."