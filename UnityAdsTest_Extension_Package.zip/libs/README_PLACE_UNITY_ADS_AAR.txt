Place unity-ads.aar in this folder. Download from Unity's maven or SDK releases. Name it: unity-ads.aar
